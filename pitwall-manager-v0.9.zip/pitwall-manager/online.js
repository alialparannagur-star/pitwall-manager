"use strict";
/* =========================================================
   PitWall Manager — ONLINE OYUN ARAYÜZÜ (v0.4)
   Giriş/kayıt → takım devralma → merkez, garaj, strateji
   (Yarışları sunucuda koşturma 4. aşamada eklenecek)
   ========================================================= */
const { COMPOUNDS, PARTS, ECONOMY, TRACK_TYPES, TRACKS, upgradeCost, upgradeGain, DRIVER_ATTRS, trainCost, driverOverall } = PW_DATA;
const E = PW_ENGINE;
const TRACK = Object.fromEntries(TRACKS.map((t) => [t.id, t]));
const PART_KEYS = Object.keys(PARTS);

const ME = { user: null, team: null, league: null, teams: [], races: [] };
let strat = null;
let countdownTimer = null;

/* ---------- Yardımcılar ---------- */
const $ = (sel) => document.querySelector(sel);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const money = (n) => "$" + Math.round(n).toLocaleString("tr-TR");
const clone = (o) => JSON.parse(JSON.stringify(o));
const degLabel = (m) => (m >= 1.15 ? "Yüksek" : m <= 0.9 ? "Düşük" : "Orta");
const otLabel = (o) => (o >= 1.1 ? "Kolay" : o <= 0.6 ? "Çok zor" : "Normal");
const fmtDate = (iso) => new Date(iso).toLocaleString("tr-TR", { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
const raceLabel = (r) => (r.title ? r.title : `Yarış ${r.round} / 25`);
const carOf = (t) => ({ engine: t.engine, aero: t.aero, chassis: t.chassis, reliability: t.reliability, pitcrew: t.pitcrew });

function show(id) {
  document.querySelectorAll(".screen").forEach((s) => s.classList.add("hidden"));
  $("#" + id).classList.remove("hidden");
  window.scrollTo(0, 0);
}

let toastTimer = null;
function toast(msg, bad) {
  const el = $("#toast");
  el.textContent = msg;
  el.className = "toast" + (bad ? " bad" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add("hidden"), 3500);
}

// Buton tıklanınca işlem bitene kadar kilitle
async function busy(btn, fn) {
  const old = btn.textContent;
  btn.disabled = true;
  btn.textContent = "Bekle…";
  try { return await fn(); }
  finally { btn.disabled = false; btn.textContent = old; }
}

/* ---------- AÇILIŞ ---------- */
async function boot() {
  show("loading");
  try {
    ME.user = await api.getUser();
    if (!ME.user) { showAuth(); return; }
    await enter();
  } catch (e) {
    $("#loading").innerHTML = `<div class="card narrow center"><p class="bad-text">${esc(e.message)}</p><button class="btn" onclick="location.reload()">Tekrar dene</button></div>`;
  }
}

async function enter() {
  $("#logoutBtn").classList.remove("hidden");
  const team = await api.myTeam();
  if (!team) { await showJoin(); return; }
  ME.team = team;
  ME.league = team.leagues;
  document.querySelector(".nav").classList.remove("hidden");
  await loadLeague();
  showHub();
}

async function loadLeague() {
  const [teams, races, world] = await Promise.all([
    api.leagueTeams(ME.league.id),
    api.leagueRaces(ME.league.id, ME.league.season_id),
    api.myWorldRaces(ME.team.id, ME.league.season_id).catch(() => []),
  ]);
  ME.teams = teams;
  // Lig yarışları + (katılıyorsa) dünya turnuvası yarışları, tarih sırasıyla
  ME.races = races.concat(world).sort((a, b) => new Date(a.scheduled_at) - new Date(b.scheduled_at));
  const fresh = teams.find((t) => t.id === ME.team.id);
  if (fresh) ME.team = Object.assign({}, ME.team, fresh);
}

/* ---------- GİRİŞ / KAYIT ---------- */
let authMode = "login";
function showAuth() {
  $("#logoutBtn").classList.add("hidden");
  $("#topInfo").textContent = "";
  setAuthMode("login");
  show("auth");
}
function setAuthMode(mode) {
  authMode = mode;
  document.querySelectorAll("[data-authmode]").forEach((b) => b.classList.toggle("active", b.dataset.authmode === mode));
  $("#authSubmit").textContent = mode === "login" ? "Giriş yap" : "Kayıt ol";
  $("#authPass").autocomplete = mode === "login" ? "current-password" : "new-password";
  $("#authMsg").textContent = "";
}
document.querySelectorAll("[data-authmode]").forEach((b) => (b.onclick = () => setAuthMode(b.dataset.authmode)));

$("#authForm").onsubmit = async (ev) => {
  ev.preventDefault();
  const email = $("#authEmail").value.trim();
  const pass = $("#authPass").value;
  const msg = $("#authMsg");
  msg.className = "form-msg";
  msg.textContent = "";
  try {
    await busy($("#authSubmit"), async () => {
      if (authMode === "signup") {
        const r = await api.signUp(email, pass);
        if (r.needsConfirm) {
          msg.className = "form-msg ok";
          msg.textContent = "Kayıt alındı! E-postana gelen bağlantıyla hesabını onayla, sonra giriş yap.";
          return;
        }
      } else {
        await api.signIn(email, pass);
      }
      ME.user = await api.getUser();
      await enter();
    });
  } catch (e) {
    msg.className = "form-msg bad";
    msg.textContent = e.message;
  }
};

$("#logoutBtn").onclick = async () => {
  await api.signOut();
  document.querySelector(".nav").classList.add("hidden");
  Object.assign(ME, { user: null, team: null, league: null, teams: [], races: [] });
  clearInterval(countdownTimer);
  showAuth();
};

/* ---------- OYUNA KATILMA ---------- */
async function showJoin() {
  $("#topInfo").textContent = "";
  const sel = $("#joinCountry");
  if (!sel.options.length) {
    const list = await api.countries();
    sel.innerHTML = `<option value="">Ülkeni seç…</option>` +
      list.map((c) => `<option value="${esc(c.code)}">${esc(c.flag)} ${esc(c.name)}</option>`).join("");
    if (list.some((c) => c.code === "TR")) sel.value = "TR";
  }
  show("join");
}

$("#joinForm").onsubmit = async (ev) => {
  ev.preventDefault();
  const msg = $("#joinMsg");
  msg.className = "form-msg";
  msg.textContent = "";
  const username = $("#joinUser").value.trim();
  const country = $("#joinCountry").value;
  if (!country) { msg.className = "form-msg bad"; msg.textContent = "Bir ülke seç."; return; }
  try {
    await busy($("#joinSubmit"), async () => {
      await api.joinGame(username, country, $("#joinTeam").value.trim());
      await enter();
      toast("Takımın hazır! Hoş geldin 🏁");
    });
  } catch (e) {
    msg.className = "form-msg bad";
    msg.textContent = e.message;
  }
};

/* ---------- MERKEZ ---------- */
function nextRace() {
  const now = Date.now();
  return ME.races.find((r) => r.status === "scheduled" && new Date(r.scheduled_at).getTime() > now) || null;
}

function leagueAvg(part) {
  if (!ME.teams.length) return 80;
  return ME.teams.reduce((s, t) => s + t[part], 0) / ME.teams.length;
}

function carStatsHtml(t) {
  return `<div class="carstats">${PART_KEYS.map((p) => `
    <span>${PARTS[p].name}</span>
    <div class="statbar"><div class="fill" style="width:${(t[p] - 60) * 2.5}%"></div><div class="avg" style="left:${(leagueAvg(p) - 60) * 2.5}%" title="Lig ortalaması"></div></div>
    <b class="num">${t[p]}</b>`).join("")}</div>
    <p class="muted small">Beyaz çizgi: lig ortalaması</p>`;
}

function showHub() {
  const t = ME.team, L = ME.league;
  $("#topInfo").textContent = `${t.name} · ${L.countries.flag} ${L.name}`;
  $("#hubTeam").textContent = t.name;
  $("#hubTeam").style.color = t.color;
  $("#hubLeague").textContent = `${L.countries.flag} ${L.name} · Sezon ${L.seasons.number}`;
  $("#hubMoney").textContent = money(t.money);
  $("#hubCar").innerHTML = carStatsHtml(t);
  const unspent = (ME.team.drivers || []).reduce((n, d) => n + (d.dev_points || 0), 0);
  $("#goPilotsBtn").innerHTML = `👤 Pilotlar${unspent ? ` <span class="badge">${unspent}</span>` : ""}`;
  renderNextRace();
  renderLastRace();
  renderCalendar();
  renderStandings();
  show("hub");
}

// Saati gelmiş ama sonucu henüz yazılmamış yarış (sunucu birkaç dakika içinde koşturur)
function liveRace() {
  const now = Date.now();
  return ME.races.find((r) => (r.status === "scheduled" || r.status === "running") && new Date(r.scheduled_at).getTime() <= now) || null;
}

function renderLastRace() {
  const done = ME.races.filter((r) => r.status === "finished");
  const card = $("#lastRaceCard");
  const live = liveRace();
  if (!done.length && !live) { card.classList.add("hidden"); return; }
  card.classList.remove("hidden");
  if (live) {
    const tr = TRACK[live.track_id];
    $("#lastRace").innerHTML = `<h2>${tr.flag} ${tr.name}</h2><p class="warn-text">🏁 Yarış şu an koşuluyor. Sonuçlar birkaç dakika içinde gelecek.</p>
      <button class="btn" id="refreshBtn">↻ Yenile</button>`;
    $("#refreshBtn").onclick = async () => { await loadLeague(); showHub(); };
    return;
  }
  const r = done[done.length - 1];
  const tr = TRACK[r.track_id];
  $("#lastRace").innerHTML = `<h2>${tr.flag} ${tr.name} <span class="muted small">${esc(raceLabel(r))}</span></h2><div id="lastRaceInfo" class="muted">Yükleniyor…</div>
    <div class="btn-row"><button class="btn primary" data-watch="${r.id}">▶ Yarışı izle</button></div>`;
  api.raceSummary(r.id, ME.team.id).then(({ results, team }) => {
    const el = $("#lastRaceInfo");
    if (!el) return;
    const drivers = ME.team.drivers.slice().sort((a, b) => a.seat - b.seat);
    const parts = drivers.map((d) => {
      const x = results.find((y) => y.driver_id === d.id);
      return x ? `${esc(d.name)}: <b>${x.dnf ? "DNF" : "P" + x.pos}</b>${x.points ? ` (+${x.points})` : ""}` : "";
    }).filter(Boolean);
    el.innerHTML = `${parts.join(" · ")}${team ? `<div class="money" style="font-size:16px;margin:6px 0 0">+${money(team.prize)} kazandın</div>` : ""}`;
  }).catch(() => {});
}

// Yarış izlendikten sonra dönülecek ekran (varsayılan: merkez)
let afterReplay = null;
async function watchRace(raceId) {
  try {
    const r = await api.raceDetail(raceId);
    if (!r.replay) { toast("Bu yarışın tekrarı yok.", true); return; }
    clearInterval(countdownTimer);
    const back = afterReplay || (async () => { await loadLeague(); showHub(); });
    PW_Replay.open({ replay: r.replay, myTeamId: ME.team.id, teamResults: r.race_team_results || [], onBack: back });
  } catch (e) { toast(e.message, true); }
}

// Sayfanın her yerindeki "İzle" ve takım bağlantıları
document.addEventListener("click", (ev) => {
  const w = ev.target.closest("[data-watch]");
  if (w) { watchRace(w.dataset.watch); return; }
  const t = ev.target.closest("[data-team]");
  if (t) { showTeam(t.dataset.team); return; }
  const l = ev.target.closest("[data-league]");
  if (l) { showLeague(l.dataset.league); return; }
});

function renderNextRace() {
  clearInterval(countdownTimer);
  const r = nextRace();
  if (!r) {
    $("#nextRace").innerHTML = `<p class="muted">Bu sezon için planlanmış başka yarış yok.</p>`;
    $("#goStrategyBtn").disabled = true;
    return;
  }
  $("#goStrategyBtn").disabled = false;
  const tr = TRACK[r.track_id];
  const key = Object.entries(TRACK_TYPES[tr.type].w).sort((a, b) => b[1] - a[1])[0][0];
  $("#nextRace").innerHTML = `
    <h2>${tr.flag} ${tr.name}</h2>
    ${r.title ? `<div class="world-tag">🌍 DÜNYA TURNUVASI · ${esc(r.title)}</div>` : ""}
    <p class="muted">${r.title ? "" : esc(raceLabel(r)) + " · "}${fmtDate(r.scheduled_at)} · ${tr.laps} tur</p>
    <p>Pist tipi: <b>${TRACK_TYPES[tr.type].name}</b> (en önemli parça: ${PARTS[key].name}) · Lastik aşınması: <b>${degLabel(tr.degMult)}</b> · Sollama: <b>${otLabel(tr.overtake)}</b></p>
    <div class="countdown" id="countdown"></div>
    <div id="stratState" class="small muted"></div>`;
  const tick = () => {
    const ms = new Date(r.scheduled_at).getTime() - Date.now();
    if (ms <= 0) { clearInterval(countdownTimer); renderNextRace(); renderLastRace(); renderCalendar(); return; }
    const d = Math.floor(ms / 864e5), h = Math.floor(ms / 36e5) % 24, m = Math.floor(ms / 6e4) % 60, s = Math.floor(ms / 1e3) % 60;
    $("#countdown").textContent = `⏱ ${d ? d + " gün " : ""}${h} sa ${m} dk ${s} sn sonra başlıyor`;
  };
  tick();
  countdownTimer = setInterval(tick, 1000);

  api.myStrategies(r.id).then((rows) => {
    const el = $("#stratState");
    if (!el) return;
    el.innerHTML = rows.length >= 2
      ? `<span class="ok-text">✓ Stratejin kaydedildi</span>`
      : `<span class="warn-text">Henüz strateji kaydetmedin. Kaydetmezsen mühendislerin önerdiği plan kullanılır.</span>`;
  }).catch(() => {});
}

function renderCalendar() {
  const next = nextRace();
  $("#calendar").innerHTML = calendarHtml(ME.races, next && next.id);
}

function calendarHtml(races, highlightId) {
  const label = { scheduled: "Planlandı", running: "Koşuluyor", finished: "Bitti", skipped: "Atlandı" };
  return races.map((r) => {
    const tr = TRACK[r.track_id];
    return `<tr class="${r.id === highlightId ? "me" : ""}">
      <td>${r.title ? "🌍" : r.round}</td><td>${tr.flag} ${tr.name}${r.title ? `<div class="small muted">${esc(r.title)}</div>` : ""}</td>
      <td class="muted">${fmtDate(r.scheduled_at)}</td>
      <td class="small">${r.status === "finished" ? `<button class="chip" data-watch="${r.id}">▶ İzle</button>` : label[r.status] || r.status}</td></tr>`;
  }).join("");
}

function renderStandings() {
  $("#hubStandings").innerHTML = standingsHtml(ME.teams);
}

// Puan tablosu (her lig için kullanılır). Takım satırına tıklayınca takım sayfası açılır.
function standingsHtml(teamList) {
  const teams = teamList.slice().sort((a, b) => b.points - a.points || a.name.localeCompare(b.name));
  const drivers = teamList.flatMap((t) => (t.drivers || []).map((d) => ({ ...d, team: t })))
    .sort((a, b) => b.points - a.points || a.name.localeCompare(b.name));
  const mine = ME.team ? ME.team.id : null;
  return `
    <div class="tabs-2">
      <div><h3>Takımlar</h3><table class="mini clickable">
        ${teams.map((t, i) => `<tr class="${t.id === mine ? "me" : ""}" data-team="${t.id}" title="Takım sayfasını aç">
          <td>${i + 1}</td>
          <td><span class="dot" style="background:${esc(t.color)}"></span>${esc(t.name)}
            <div class="small muted">${t.owner_id ? "👤 " + esc(t.profiles ? t.profiles.username : "oyuncu") : "🤖 bot"}</div></td>
          <td class="num">${t.points}</td></tr>`).join("")}
      </table></div>
      <div><h3>Pilotlar</h3><table class="mini clickable">
        ${drivers.map((d, i) => `<tr class="${d.team.id === mine ? "me" : ""}" data-team="${d.team.id}">
          <td>${i + 1}</td><td><span class="dot" style="background:${esc(d.team.color)}"></span>${esc(d.name)}
            <span class="muted small">${driverOverall(d)}</span></td>
          <td class="num">${d.points}</td></tr>`).join("")}
      </table></div>
    </div>`;
}

/* ---------- TAKIM SAYFASI ---------- */
let teamBack = null;
async function showTeam(teamId) {
  const cur = currentScreen();
  const backTo = ["race", "results", "teamPage"].includes(cur) ? teamBack : cur;
  try {
    const [t, results] = await Promise.all([api.team(teamId), api.teamResults(teamId)]);
    const leagueTeams = t.league_id === ME.league.id ? ME.teams : await api.leagueTeams(t.league_id);
    const avg = (p) => leagueTeams.reduce((s, x) => s + x[p], 0) / leagueTeams.length;
    const rank = leagueTeams.slice().sort((a, b) => b.points - a.points || a.name.localeCompare(b.name)).findIndex((x) => x.id === t.id) + 1;
    const L = t.leagues;
    const drivers = (t.drivers || []).slice().sort((a, b) => a.seat - b.seat);

    // Yarış yarış sonuçlar (iki pilot yan yana)
    const byRound = {};
    results.forEach((r) => {
      if (!r.races) return;
      const k = r.races.round;
      byRound[k] = byRound[k] || { round: k, track: r.races.track_id, raceId: r.race_id, cells: {}, pts: 0 };
      byRound[k].cells[r.driver_id] = r;
      byRound[k].pts += r.points;
    });
    const rounds = Object.values(byRound).sort((a, b) => b.round - a.round);
    const posCls = (x) => (!x ? "" : x.dnf ? "res-dnf" : x.pos === 1 ? "res-win" : x.pos <= 3 ? "res-pod" : x.pos <= 10 ? "res-pts" : "");

    $("#teamPageBody").innerHTML = `
      <div class="team-hero" style="border-top:6px solid ${esc(t.color)}">
        <div>
          <h1 style="color:${esc(t.color)}">${esc(t.name)}</h1>
          <div class="muted">${t.owner_id ? "👤 Menajer: <b>" + esc(t.profiles ? t.profiles.username : "oyuncu") + "</b>" : "🤖 Bot takım"}
            · <a href="#" data-league="${L.id}">${esc(L.countries.flag)} ${esc(L.name)}</a></div>
        </div>
        <div class="hero-stats">
          <div><span>${rank}.</span><small>SIRA</small></div>
          <div><span>${t.points}</span><small>PUAN</small></div>
          <div><span>${rounds.length}</span><small>YARIŞ</small></div>
        </div>
      </div>

      <div id="teamTrophies" class="trophies"></div>
      <div class="team-grid-2">
        <div>
          <h3>Araç</h3>
          <div class="carstats">${PART_KEYS.map((p) => `
            <span>${PARTS[p].name}</span>
            <div class="statbar"><div class="fill" style="width:${(t[p] - 60) * 2.5}%;background:${esc(t.color)}"></div><div class="avg" style="left:${(avg(p) - 60) * 2.5}%"></div></div>
            <b class="num">${t[p]}</b>`).join("")}</div>
          <p class="muted small">Beyaz çizgi: lig ortalaması</p>
        </div>
        <div>
          <h3>Pilotlar</h3>
          ${drivers.map((d) => `
            <div class="mini-pilot">
              <div class="mp-head"><b>${esc(d.name)}</b><span class="mp-ovr">${driverOverall(d)}</span></div>
              <div class="mp-attrs">${Object.entries(DRIVER_ATTRS).map(([a, info]) => `<span>${info.name} <b>${d[a] ?? "—"}</b></span>`).join("")}</div>
              <div class="muted small">${d.points} puan · ${d.races || 0} yarış</div>
            </div>`).join("")}
        </div>
      </div>

      <h3 style="margin-top:18px">Sezon sonuçları</h3>
      ${rounds.length ? `<table class="mini res-table">
        <tr><th>#</th><th>Yarış</th>${drivers.map((d) => `<th>${esc(d.name.split(" ").slice(-1)[0])}</th>`).join("")}<th class="num">Puan</th><th></th></tr>
        ${rounds.map((r) => `<tr>
          <td>${r.round}</td><td>${TRACK[r.track].flag} ${TRACK[r.track].name}</td>
          ${drivers.map((d) => { const x = r.cells[d.id]; return `<td><span class="res ${posCls(x)}">${!x ? "—" : x.dnf ? "DNF" : "P" + x.pos}</span></td>`; }).join("")}
          <td class="num">${r.pts || ""}</td>
          <td><button class="chip" data-watch="${r.raceId}">▶</button></td></tr>`).join("")}
      </table>` : `<p class="muted">Henüz koşulmuş yarış yok.</p>`}`;

    teamBack = backTo;
    afterReplay = async () => { afterReplay = null; await showTeam(teamId); };
    show("teamPage");
    api.trophies(teamId).then((list) => {
      const el = $("#teamTrophies");
      if (el && list.length) el.innerHTML = list.map((x) => `<span class="trophy ${esc(x.kind)}">${esc(x.label)}</span>`).join("");
    }).catch(() => {});
  } catch (e) { toast(e.message, true); }
}

function currentScreen() {
  const s = [...document.querySelectorAll(".screen")].find((x) => !x.classList.contains("hidden"));
  return s ? s.id : "hub";
}

// Geri: takım sayfasını hangi ekrandan açtıysan oraya döner
async function goBackFrom(page) {
  afterReplay = null;
  const target = page === "teamPage" ? teamBack : leagueBack;
  if (target === "leaguePage" && currentLeagueId) return showLeague(currentLeagueId);
  if (target === "leagues") return showLeagues();
  if (target === "world") return showWorld();
  await loadLeague();
  showHub();
}

/* ---------- LİGLER (TÜM ÜLKELER) ---------- */
async function showLeagues() {
  afterReplay = null;
  try {
    const list = await api.leaguesOverview(ME.league.season_id);
    const byCountry = {};
    list.forEach((l) => { (byCountry[l.country_code] = byCountry[l.country_code] || { c: l.countries, leagues: [] }).leagues.push(l); });
    const countries = Object.values(byCountry).sort((a, b) =>
      b.leagues.reduce((n, l) => n + l.teams.filter((t) => t.owner_id).length, 0) - a.leagues.reduce((n, l) => n + l.teams.filter((t) => t.owner_id).length, 0) || a.c.name.localeCompare(b.c.name));
    const players = list.reduce((n, l) => n + l.teams.filter((t) => t.owner_id).length, 0);
    $("#leaguesSummary").textContent = `${countries.length} ülke · ${list.length} lig · ${players} oyuncu`;
    $("#leaguesBody").innerHTML = countries.length ? countries.map(({ c, leagues }) => `
      <div class="country-block" data-search="${esc(c.name.toLocaleLowerCase("tr"))}">
        <h3 class="country-name">${esc(c.flag)} ${esc(c.name)}</h3>
        <div class="league-cards">
          ${leagues.sort((a, b) => a.tier - b.tier).map((l) => {
            const humans = l.teams.filter((t) => t.owner_id).length;
            const leader = l.teams.slice().sort((a, b) => b.points - a.points || a.name.localeCompare(b.name))[0];
            return `<button class="league-card ${l.id === ME.league.id ? "mine" : ""}" data-league="${l.id}">
              <div class="lc-name">${esc(l.name)}${l.id === ME.league.id ? ' <span class="badge">senin ligin</span>' : ""}</div>
              <div class="muted small">👤 ${humans} oyuncu · 🤖 ${l.teams.length - humans} bot</div>
              ${leader && leader.points ? `<div class="small">Lider: <span class="dot" style="background:${esc(leader.color)}"></span>${esc(leader.name)} (${leader.points})</div>` : `<div class="small muted">Henüz yarış yok</div>`}
            </button>`;
          }).join("")}
        </div>
      </div>`).join("") : `<p class="muted">Henüz lig yok.</p>`;
    filterLeagues();
    show("leagues");
  } catch (e) { toast(e.message, true); }
}

function filterLeagues() {
  const q = $("#leagueSearch").value.trim().toLocaleLowerCase("tr");
  document.querySelectorAll("#leaguesBody .country-block").forEach((b) => b.classList.toggle("hidden", !!q && !b.dataset.search.includes(q)));
}
$("#leagueSearch").oninput = filterLeagues;

/* ---------- DÜNYA TURNUVASI ---------- */
const STAGES = [
  { key: "final",  title: "🏆 Büyük Final", desc: "12 takım, 2 yarış. En çok puanı toplayan dünya şampiyonu olur.", qualify: 0 },
  { key: "group",  title: "Grup aşaması",   desc: "Ülke şampiyonları ve eleme galipleri. 2 yarış, her grubun ilk 3'ü finale çıkar.", qualify: 3 },
  { key: "playin", title: "Eleme turu",     desc: "Ülke ikincileri. 1 yarış, her grubun birincisi grup aşamasına çıkar.", qualify: 1 },
];

async function showWorld() {
  afterReplay = null;
  try {
    const S = ME.league.seasons;
    const groups = await api.worldOverview(ME.league.season_id);
    const startDay = (n) => { const d = new Date(S.start_date + "T18:00:00Z"); d.setUTCDate(d.getUTCDate() + n - 1); return d; };
    const fmtDay = (d) => d.toLocaleString("tr-TR", { day: "numeric", month: "long", weekday: "long", hour: "2-digit", minute: "2-digit" });
    let html = "";

    // Geçen sezonun kazananları
    if (S.number > 1) {
      const prev = await api.lastWorldWinners(S.number - 1).catch(() => []);
      if (prev.length) {
        const order = { world_champion: 1, world_second: 2, world_third: 3 };
        html += `<div class="card"><h3>Sezon ${S.number - 1} kazananları</h3><div class="podium">${prev.sort((a, b) => order[a.kind] - order[b.kind]).map((x) =>
          `<div class="pod pod-${order[x.kind]}" ${x.team_id ? `data-team="${x.team_id}"` : ""}><div class="pod-medal">${["🏆", "🥈", "🥉"][order[x.kind] - 1]}</div><b>${esc(x.team_name)}</b></div>`).join("")}</div></div>`;
      }
    }

    if (!groups.length) {
      html += `<div class="card">
        <h2>🌍 Dünya turnuvası</h2>
        <p>Lig sezonu bitince 40 ülkenin en iyileri dünya şampiyonluğu için yarışır. Bot takımlar da katılır.</p>
        <div class="world-steps">
          <div><b>1. Eleme turu</b><span>${fmtDay(startDay(26))}</span><p class="muted small">Ülke ikincileri 4 grupta yarışır. Her grubun birincisi devam eder.</p></div>
          <div><b>2. Grup aşaması</b><span>${fmtDay(startDay(27))} ve ertesi gün</span><p class="muted small">Ülke şampiyonları + 4 eleme galibi, 11'erli 4 grup, 2 yarış. Her grubun ilk 3'ü finale çıkar.</p></div>
          <div><b>3. Büyük final</b><span>${fmtDay(startDay(29))} ve ertesi gün</span><p class="muted small">12 takım, 2 yarış. Dünya şampiyonu belirlenir.</p></div>
        </div>
        <p class="muted small">Ödüller: şampiyon $5.000.000, ikinci $3.000.000, üçüncü $2.000.000, diğer finalistler $1.000.000, grup aşaması katılımcıları $500.000. Ayrıca kalıcı kupa rozetleri.</p>
        <p class="muted small">Takımını oraya taşımak için ligini ilk iki sırada bitir!</p>
      </div>`;
    }

    STAGES.forEach((st) => {
      const gs = groups.filter((g) => g.stage === st.key).sort((a, b) => a.sort - b.sort);
      if (!gs.length) return;
      html += `<div class="stage"><h2>${st.title}</h2><p class="muted small">${st.desc}</p><div class="world-groups ${st.key === "final" ? "single" : ""}">`;
      gs.forEach((g) => {
        const rows = (g.world_group_teams || []).slice().sort((a, b) => b.points - a.points || (a.best_pos || 99) - (b.best_pos || 99) || a.teams.name.localeCompare(b.teams.name));
        const races = (g.races || []).slice().sort((a, b) => a.round - b.round);
        const done = races.length && races.every((r) => r.status === "finished");
        html += `<div class="card world-group">
          <h3>${esc(g.name)}${done ? ' <span class="muted small">· tamamlandı</span>' : ""}</h3>
          <table class="mini clickable">${rows.map((x, i) => {
            const t = x.teams;
            const q = st.qualify ? i < st.qualify : i === 0;
            const flag = t.leagues && t.leagues.countries ? t.leagues.countries.flag : "";
            return `<tr class="${t.id === ME.team.id ? "me" : ""}" data-team="${t.id}">
              <td>${i + 1}</td>
              <td>${q && done ? (st.key === "final" ? "🏆 " : "✅ ") : ""}${esc(flag)} <span class="dot" style="background:${esc(t.color)}"></span>${esc(t.name)}
                <div class="small muted">${esc(x.seed_info || "")} · ${t.owner_id ? "👤 " + esc(t.profiles ? t.profiles.username : "oyuncu") : "🤖 bot"}</div></td>
              <td class="num">${x.points}</td></tr>`;
          }).join("")}</table>
          <div class="world-races">${races.map((r) => {
            const tr = TRACK[r.track_id];
            return `<div class="wr-row"><span>${tr.flag} ${tr.name}</span><span class="muted small">${fmtDate(r.scheduled_at)}</span>
              ${r.status === "finished" ? `<button class="chip" data-watch="${r.id}">▶ İzle</button>` : `<span class="small muted">${r.status === "running" ? "Koşuluyor" : "Planlandı"}</span>`}</div>`;
          }).join("")}</div>
        </div>`;
      });
      html += `</div></div>`;
    });

    $("#worldBody").innerHTML = html;
    afterReplay = async () => { afterReplay = null; await showWorld(); };
    show("world");
  } catch (e) { toast(e.message, true); }
}

/* ---------- LİG SAYFASI ---------- */
let currentLeagueId = null, leagueBack = null;
async function showLeague(leagueId) {
  if (leagueId === ME.league.id && currentScreen() !== "leagues") { await loadLeague(); showHub(); return; }
  const cur = currentScreen();
  const backTo = ["race", "results", "leaguePage"].includes(cur) ? leagueBack : cur;
  try {
    const L = await api.league(leagueId);
    const [teams, races] = await Promise.all([api.leagueTeams(leagueId), api.leagueRaces(leagueId, L.season_id)]);
    const now = Date.now();
    const next = races.find((r) => r.status === "scheduled" && new Date(r.scheduled_at).getTime() > now);
    $("#leagueTitle").innerHTML = `${esc(L.countries.flag)} ${esc(L.name)} <span class="muted small">Sezon ${L.seasons.number}</span>`;
    $("#leagueStandings").innerHTML = standingsHtml(teams);
    $("#leagueCalendar").innerHTML = calendarHtml(races, next && next.id);
    currentLeagueId = leagueId;
    leagueBack = backTo === "teamPage" || !backTo ? "leagues" : backTo;
    afterReplay = async () => { afterReplay = null; await showLeague(leagueId); };
    show("leaguePage");
  } catch (e) { toast(e.message, true); }
}

/* ---------- GARAJ ---------- */
function showGarage() {
  const t = ME.team;
  $("#garageMoney").textContent = money(t.money);
  $("#parts").innerHTML = PART_KEYS.map((p) => {
    const lvl = (t.levels && t.levels[p]) || 0, cost = upgradeCost(lvl), val = t[p];
    const maxed = val >= ECONOMY.statMax;
    const can = !maxed && t.money >= cost;
    return `<div class="part">
      <div>
        <div class="name">${PARTS[p].name} <span class="muted small">· Seviye ${lvl}</span></div>
        <div class="desc">${PARTS[p].desc}</div>
        <div class="statbar"><div class="fill" style="width:${(val - 60) * 2.5}%"></div><div class="avg" style="left:${(leagueAvg(p) - 60) * 2.5}%"></div></div>
        <div class="small muted" style="margin-top:4px">Değer: <b style="color:var(--text)">${val}</b> · Lig ortalaması: ${leagueAvg(p).toFixed(1)}</div>
      </div>
      <button class="btn ${can ? "primary" : ""}" data-buy="${p}" ${can ? "" : "disabled"}>
        ${maxed ? "Maksimum" : `+${upgradeGain(val)} · ${money(cost)}`}
      </button>
    </div>`;
  }).join("");
  $("#parts").querySelectorAll("[data-buy]").forEach((b) => (b.onclick = async () => {
    try {
      await busy(b, async () => {
        const updated = await api.buyUpgrade(b.dataset.buy);
        Object.assign(ME.team, updated);
        const i = ME.teams.findIndex((x) => x.id === ME.team.id);
        if (i >= 0) Object.assign(ME.teams[i], updated);
        toast(`${PARTS[b.dataset.buy].name} geliştirildi! 🔧`);
      });
      showGarage();
    } catch (e) { toast(e.message, true); }
  }));
  show("garage");
}

/* ---------- PİLOTLAR ---------- */
function showPilots() {
  const drivers = ME.team.drivers.slice().sort((a, b) => a.seat - b.seat);
  $("#pilotCards").innerHTML = drivers.map((d) => `
    <div class="card driver-panel pilot-card" style="border-left-color:${esc(ME.team.color)}">
      <div class="pilot-head">
        <div>
          <h2>${esc(d.name)}</h2>
          <div class="muted small">${d.seat}. pilot · ${d.races || 0} yarış · ${d.points} şampiyona puanı</div>
        </div>
        <div class="overall"><span>${driverOverall(d)}</span><small>GENEL</small></div>
      </div>
      <div class="devpts">Gelişim puanı: <b>${d.dev_points || 0}</b></div>
      ${Object.entries(DRIVER_ATTRS).map(([a, info]) => {
        const v = d[a], cost = trainCost(v), can = v < 99 && (d.dev_points || 0) >= cost;
        return `<div class="attr-row">
          <div>
            <div class="name">${info.name} <b class="num">${v}</b></div>
            <div class="desc">${info.desc}</div>
            <div class="statbar"><div class="fill" style="width:${(v - 60) * 2.5}%"></div></div>
          </div>
          <button class="btn ${can ? "primary" : ""}" data-train="${d.id}:${a}" ${can ? "" : "disabled"}>${v >= 99 ? "Maksimum" : `+1 · ${cost} puan`}</button>
        </div>`;
      }).join("")}
    </div>`).join("");
  $("#pilotCards").querySelectorAll("[data-train]").forEach((b) => (b.onclick = async () => {
    const [id, attr] = b.dataset.train.split(":");
    try {
      await busy(b, async () => {
        const updated = await api.trainDriver(id, attr);
        const d = ME.team.drivers.find((x) => x.id === id);
        Object.assign(d, updated);
        const lt = ME.teams.find((x) => x.id === ME.team.id);
        if (lt) { const ld = lt.drivers.find((x) => x.id === id); if (ld) Object.assign(ld, updated); }
        toast(`${d.name}: ${DRIVER_ATTRS[attr].name} +1 💪`);
      });
      showPilots();
    } catch (e) { toast(e.message, true); }
  }));
  show("pilots");
}

/* ---------- STRATEJİ ---------- */
async function showStrategy() {
  const r = nextRace();
  if (!r) return;
  const tr = TRACK[r.track_id];
  const car = carOf(ME.team);
  const drivers = ME.team.drivers.slice().sort((a, b) => a.seat - b.seat);
  const suggs = drivers.map((d) => E.suggestStrategies(tr, car, 4, d));

  let saved = [];
  try { saved = await api.myStrategies(r.id); } catch (e) { toast(e.message, true); }
  const plans = drivers.map((d, k) => {
    const s = saved.find((x) => x.driver_id === d.id);
    return s ? PW_Strategy.normalize(s.plan, tr) : clone(suggs[k][Math.min(k, suggs[k].length - 1)].plan);
  });

  strat = { race: r, track: tr, drivers, dirty: false };
  strat.ctx = { track: tr, car, drivers, color: ME.team.color, plans, suggs, onChange: () => { strat.dirty = true; updateStratStatus(saved.length > 0); } };

  $("#stratTitle").textContent = `${tr.flag} ${tr.name} · ${r.title ? "🌍 " + r.title : "Yarış " + r.round}`;
  $("#stratInfo").textContent = `${fmtDate(r.scheduled_at)} · ${tr.laps} tur · Lastik aşınması: ${degLabel(tr.degMult)} · Sollama: ${otLabel(tr.overtake)} · Pit kaybı ~${tr.pitLoss} sn`;
  updateStratStatus(saved.length > 0);
  PW_Strategy.render($("#plans"), strat.ctx);
  show("strategy");
}

function updateStratStatus(hasSaved) {
  $("#stratStatus").innerHTML = strat.dirty
    ? `<span class="warn-text">● Kaydedilmemiş değişiklikler var</span>`
    : hasSaved ? `<span class="ok-text">✓ Strateji kayıtlı</span>` : `<span class="muted">Mühendislerin önerisi yüklendi, henüz kaydedilmedi</span>`;
}

$("#saveStratBtn").onclick = async () => {
  if (!strat) return;
  if (new Date(strat.race.scheduled_at).getTime() <= Date.now()) { toast("Yarış başladı, strateji artık değiştirilemez.", true); return; }
  try {
    await busy($("#saveStratBtn"), () => api.saveStrategies(strat.race.id,
      strat.drivers.map((d, k) => ({ driverId: d.id, plan: strat.ctx.plans[k] }))));
    strat.dirty = false;
    updateStratStatus(true);
    toast("Strateji kaydedildi ✓");
  } catch (e) { toast(e.message, true); }
};

$("#stratBack").onclick = () => {
  if (strat && strat.dirty && !confirmLeave()) return;
  showHub();
};
// Kaydedilmemiş değişiklik varsa ilk tıklamada uyar
let leaveArmed = false;
function confirmLeave() {
  if (leaveArmed) { leaveArmed = false; return true; }
  leaveArmed = true;
  toast("Kaydedilmemiş değişiklikler var. Çıkmak için tekrar tıkla.", true);
  setTimeout(() => (leaveArmed = false), 3500);
  return false;
}

/* ---------- BUTONLAR ---------- */
$("#goStrategyBtn").onclick = showStrategy;
$("#goGarageBtn").onclick = showGarage;
$("#goPilotsBtn").onclick = showPilots;
$("#navHub").onclick = async () => { afterReplay = null; await loadLeague(); showHub(); };
$("#navLeagues").onclick = showLeagues;
$("#navWorld").onclick = showWorld;
$("#teamBack").onclick = () => goBackFrom("teamPage");
$("#leagueBack").onclick = () => goBackFrom("leaguePage");
$("#pilotsBack").onclick = showHub;
$("#garageBack").onclick = showHub;

boot();
