"use strict";
/* =========================================================
   PitWall Manager — ONLINE OYUN ARAYÜZÜ (v0.4)
   Giriş/kayıt → takım devralma → merkez, garaj, strateji
   (Yarışları sunucuda koşturma 4. aşamada eklenecek)
   ========================================================= */
const { COMPOUNDS, PARTS, ECONOMY, TRACK_TYPES, TRACKS, upgradeCost, upgradeGain } = PW_DATA;
const E = PW_ENGINE;
const TRACK = Object.fromEntries(TRACKS.map((t) => [t.id, t]));
const PART_KEYS = Object.keys(PARTS);

const ME = { user: null, team: null, league: null, teams: [], races: [] };
let strat = null;
let countdownTimer = null;

/* ---------- Yardımcılar ---------- */
const $ = (sel) => document.querySelector(sel);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const money = (n) => "$" + Math.round(n).toLocaleString("tr-TR");
const clone = (o) => JSON.parse(JSON.stringify(o));
const degLabel = (m) => (m >= 1.15 ? "Yüksek" : m <= 0.9 ? "Düşük" : "Orta");
const otLabel = (o) => (o >= 1.1 ? "Kolay" : o <= 0.6 ? "Çok zor" : "Normal");
const fmtDate = (iso) => new Date(iso).toLocaleString("tr-TR", { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
const carOf = (t) => ({ engine: t.engine, aero: t.aero, chassis: t.chassis, reliability: t.reliability, pitcrew: t.pitcrew });

function show(id) {
  document.querySelectorAll(".screen").forEach((s) => s.classList.add("hidden"));
  $("#" + id).classList.remove("hidden");
  window.scrollTo(0, 0);
}

let toastTimer = null;
function toast(msg, bad) {
  const el = $("#toast");
  el.textContent = msg;
  el.className = "toast" + (bad ? " bad" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add("hidden"), 3500);
}

// Buton tıklanınca işlem bitene kadar kilitle
async function busy(btn, fn) {
  const old = btn.textContent;
  btn.disabled = true;
  btn.textContent = "Bekle…";
  try { return await fn(); }
  finally { btn.disabled = false; btn.textContent = old; }
}

/* ---------- AÇILIŞ ---------- */
async function boot() {
  show("loading");
  try {
    ME.user = await api.getUser();
    if (!ME.user) { showAuth(); return; }
    await enter();
  } catch (e) {
    $("#loading").innerHTML = `<div class="card narrow center"><p class="bad-text">${esc(e.message)}</p><button class="btn" onclick="location.reload()">Tekrar dene</button></div>`;
  }
}

async function enter() {
  $("#logoutBtn").classList.remove("hidden");
  const team = await api.myTeam();
  if (!team) { await showJoin(); return; }
  ME.team = team;
  ME.league = team.leagues;
  await loadLeague();
  showHub();
}

async function loadLeague() {
  const [teams, races] = await Promise.all([api.leagueTeams(ME.league.id), api.leagueRaces(ME.league.id)]);
  ME.teams = teams;
  ME.races = races;
  const fresh = teams.find((t) => t.id === ME.team.id);
  if (fresh) ME.team = Object.assign({}, ME.team, fresh);
}

/* ---------- GİRİŞ / KAYIT ---------- */
let authMode = "login";
function showAuth() {
  $("#logoutBtn").classList.add("hidden");
  $("#topInfo").textContent = "";
  setAuthMode("login");
  show("auth");
}
function setAuthMode(mode) {
  authMode = mode;
  document.querySelectorAll("[data-authmode]").forEach((b) => b.classList.toggle("active", b.dataset.authmode === mode));
  $("#authSubmit").textContent = mode === "login" ? "Giriş yap" : "Kayıt ol";
  $("#authPass").autocomplete = mode === "login" ? "current-password" : "new-password";
  $("#authMsg").textContent = "";
}
document.querySelectorAll("[data-authmode]").forEach((b) => (b.onclick = () => setAuthMode(b.dataset.authmode)));

$("#authForm").onsubmit = async (ev) => {
  ev.preventDefault();
  const email = $("#authEmail").value.trim();
  const pass = $("#authPass").value;
  const msg = $("#authMsg");
  msg.className = "form-msg";
  msg.textContent = "";
  try {
    await busy($("#authSubmit"), async () => {
      if (authMode === "signup") {
        const r = await api.signUp(email, pass);
        if (r.needsConfirm) {
          msg.className = "form-msg ok";
          msg.textContent = "Kayıt alındı! E-postana gelen bağlantıyla hesabını onayla, sonra giriş yap.";
          return;
        }
      } else {
        await api.signIn(email, pass);
      }
      ME.user = await api.getUser();
      await enter();
    });
  } catch (e) {
    msg.className = "form-msg bad";
    msg.textContent = e.message;
  }
};

$("#logoutBtn").onclick = async () => {
  await api.signOut();
  Object.assign(ME, { user: null, team: null, league: null, teams: [], races: [] });
  clearInterval(countdownTimer);
  showAuth();
};

/* ---------- OYUNA KATILMA ---------- */
async function showJoin() {
  $("#topInfo").textContent = "";
  const sel = $("#joinCountry");
  if (!sel.options.length) {
    const list = await api.countries();
    sel.innerHTML = `<option value="">Ülkeni seç…</option>` +
      list.map((c) => `<option value="${esc(c.code)}">${esc(c.flag)} ${esc(c.name)}</option>`).join("");
    if (list.some((c) => c.code === "TR")) sel.value = "TR";
  }
  show("join");
}

$("#joinForm").onsubmit = async (ev) => {
  ev.preventDefault();
  const msg = $("#joinMsg");
  msg.className = "form-msg";
  msg.textContent = "";
  const username = $("#joinUser").value.trim();
  const country = $("#joinCountry").value;
  if (!country) { msg.className = "form-msg bad"; msg.textContent = "Bir ülke seç."; return; }
  try {
    await busy($("#joinSubmit"), async () => {
      await api.joinGame(username, country, $("#joinTeam").value.trim());
      await enter();
      toast("Takımın hazır! Hoş geldin 🏁");
    });
  } catch (e) {
    msg.className = "form-msg bad";
    msg.textContent = e.message;
  }
};

/* ---------- MERKEZ ---------- */
function nextRace() {
  const now = Date.now();
  return ME.races.find((r) => r.status === "scheduled" && new Date(r.scheduled_at).getTime() > now) || null;
}

function leagueAvg(part) {
  if (!ME.teams.length) return 80;
  return ME.teams.reduce((s, t) => s + t[part], 0) / ME.teams.length;
}

function carStatsHtml(t) {
  return `<div class="carstats">${PART_KEYS.map((p) => `
    <span>${PARTS[p].name}</span>
    <div class="statbar"><div class="fill" style="width:${(t[p] - 60) * 2.5}%"></div><div class="avg" style="left:${(leagueAvg(p) - 60) * 2.5}%" title="Lig ortalaması"></div></div>
    <b class="num">${t[p]}</b>`).join("")}</div>
    <p class="muted small">Beyaz çizgi: lig ortalaması</p>`;
}

function showHub() {
  const t = ME.team, L = ME.league;
  $("#topInfo").textContent = `${t.name} · ${L.countries.flag} ${L.name}`;
  $("#hubTeam").textContent = t.name;
  $("#hubTeam").style.color = t.color;
  $("#hubLeague").textContent = `${L.countries.flag} ${L.name} · Sezon ${L.seasons.number}`;
  $("#hubMoney").textContent = money(t.money);
  $("#hubCar").innerHTML = carStatsHtml(t);
  renderNextRace();
  renderCalendar();
  renderStandings();
  show("hub");
}

function renderNextRace() {
  clearInterval(countdownTimer);
  const r = nextRace();
  if (!r) {
    $("#nextRace").innerHTML = `<p class="muted">Bu sezon için planlanmış başka yarış yok.</p>`;
    $("#goStrategyBtn").disabled = true;
    return;
  }
  $("#goStrategyBtn").disabled = false;
  const tr = TRACK[r.track_id];
  const key = Object.entries(TRACK_TYPES[tr.type].w).sort((a, b) => b[1] - a[1])[0][0];
  $("#nextRace").innerHTML = `
    <h2>${tr.flag} ${tr.name}</h2>
    <p class="muted">Yarış ${r.round} / 25 · ${fmtDate(r.scheduled_at)} · ${tr.laps} tur</p>
    <p>Pist tipi: <b>${TRACK_TYPES[tr.type].name}</b> (en önemli parça: ${PARTS[key].name}) · Lastik aşınması: <b>${degLabel(tr.degMult)}</b> · Sollama: <b>${otLabel(tr.overtake)}</b></p>
    <div class="countdown" id="countdown"></div>
    <div id="stratState" class="small muted"></div>`;
  const tick = () => {
    const ms = new Date(r.scheduled_at).getTime() - Date.now();
    if (ms <= 0) { clearInterval(countdownTimer); $("#countdown").textContent = "Yarış başladı!"; return; }
    const d = Math.floor(ms / 864e5), h = Math.floor(ms / 36e5) % 24, m = Math.floor(ms / 6e4) % 60, s = Math.floor(ms / 1e3) % 60;
    $("#countdown").textContent = `⏱ ${d ? d + " gün " : ""}${h} sa ${m} dk ${s} sn sonra başlıyor`;
  };
  tick();
  countdownTimer = setInterval(tick, 1000);

  api.myStrategies(r.id).then((rows) => {
    const el = $("#stratState");
    if (!el) return;
    el.innerHTML = rows.length >= 2
      ? `<span class="ok-text">✓ Stratejin kaydedildi</span>`
      : `<span class="warn-text">Henüz strateji kaydetmedin. Kaydetmezsen mühendislerin önerdiği plan kullanılır.</span>`;
  }).catch(() => {});
}

function renderCalendar() {
  const next = nextRace();
  const label = { scheduled: "Planlandı", finished: "Bitti", skipped: "Atlandı" };
  $("#calendar").innerHTML = ME.races.map((r) => {
    const tr = TRACK[r.track_id];
    return `<tr class="${next && r.id === next.id ? "me" : ""}">
      <td>${r.round}</td><td>${tr.flag} ${tr.name}</td>
      <td class="muted">${fmtDate(r.scheduled_at)}</td>
      <td class="small">${label[r.status] || r.status}</td></tr>`;
  }).join("");
}

function renderStandings() {
  const teams = ME.teams.slice().sort((a, b) => b.points - a.points || a.name.localeCompare(b.name));
  const drivers = ME.teams.flatMap((t) => t.drivers.map((d) => ({ ...d, team: t })))
    .sort((a, b) => b.points - a.points || a.name.localeCompare(b.name));
  $("#hubStandings").innerHTML = `
    <div class="tabs-2">
      <div><h3>Takımlar</h3><table class="mini">
        ${teams.map((t, i) => `<tr class="${t.id === ME.team.id ? "me" : ""}">
          <td>${i + 1}</td>
          <td><span class="dot" style="background:${esc(t.color)}"></span>${esc(t.name)}
            <div class="small muted">${t.owner_id ? "👤 " + esc(t.profiles ? t.profiles.username : "oyuncu") : "🤖 bot"}</div></td>
          <td class="num">${t.points}</td></tr>`).join("")}
      </table></div>
      <div><h3>Pilotlar</h3><table class="mini">
        ${drivers.map((d, i) => `<tr class="${d.team.id === ME.team.id ? "me" : ""}">
          <td>${i + 1}</td><td><span class="dot" style="background:${esc(d.team.color)}"></span>${esc(d.name)}</td>
          <td class="num">${d.points}</td></tr>`).join("")}
      </table></div>
    </div>`;
}

/* ---------- GARAJ ---------- */
function showGarage() {
  const t = ME.team;
  $("#garageMoney").textContent = money(t.money);
  $("#parts").innerHTML = PART_KEYS.map((p) => {
    const lvl = (t.levels && t.levels[p]) || 0, cost = upgradeCost(lvl), val = t[p];
    const maxed = val >= ECONOMY.statMax;
    const can = !maxed && t.money >= cost;
    return `<div class="part">
      <div>
        <div class="name">${PARTS[p].name} <span class="muted small">· Seviye ${lvl}</span></div>
        <div class="desc">${PARTS[p].desc}</div>
        <div class="statbar"><div class="fill" style="width:${(val - 60) * 2.5}%"></div><div class="avg" style="left:${(leagueAvg(p) - 60) * 2.5}%"></div></div>
        <div class="small muted" style="margin-top:4px">Değer: <b style="color:var(--text)">${val}</b> · Lig ortalaması: ${leagueAvg(p).toFixed(1)}</div>
      </div>
      <button class="btn ${can ? "primary" : ""}" data-buy="${p}" ${can ? "" : "disabled"}>
        ${maxed ? "Maksimum" : `+${upgradeGain(val)} · ${money(cost)}`}
      </button>
    </div>`;
  }).join("");
  $("#parts").querySelectorAll("[data-buy]").forEach((b) => (b.onclick = async () => {
    try {
      await busy(b, async () => {
        const updated = await api.buyUpgrade(b.dataset.buy);
        Object.assign(ME.team, updated);
        const i = ME.teams.findIndex((x) => x.id === ME.team.id);
        if (i >= 0) Object.assign(ME.teams[i], updated);
        toast(`${PARTS[b.dataset.buy].name} geliştirildi! 🔧`);
      });
      showGarage();
    } catch (e) { toast(e.message, true); }
  }));
  show("garage");
}

/* ---------- STRATEJİ ---------- */
async function showStrategy() {
  const r = nextRace();
  if (!r) return;
  const tr = TRACK[r.track_id];
  const car = carOf(ME.team);
  const drivers = ME.team.drivers.slice().sort((a, b) => a.seat - b.seat);
  const sugg = E.suggestStrategies(tr, car, 4);

  let saved = [];
  try { saved = await api.myStrategies(r.id); } catch (e) { toast(e.message, true); }
  const plans = drivers.map((d, k) => {
    const s = saved.find((x) => x.driver_id === d.id);
    return s ? PW_Strategy.normalize(s.plan, tr) : clone(sugg[Math.min(k, sugg.length - 1)].plan);
  });

  strat = { race: r, track: tr, drivers, dirty: false };
  strat.ctx = { track: tr, car, drivers, color: ME.team.color, plans, sugg, onChange: () => { strat.dirty = true; updateStratStatus(saved.length > 0); } };

  $("#stratTitle").textContent = `${tr.flag} ${tr.name} · Yarış ${r.round}`;
  $("#stratInfo").textContent = `${fmtDate(r.scheduled_at)} · ${tr.laps} tur · Lastik aşınması: ${degLabel(tr.degMult)} · Sollama: ${otLabel(tr.overtake)} · Pit kaybı ~${tr.pitLoss} sn`;
  updateStratStatus(saved.length > 0);
  PW_Strategy.render($("#plans"), strat.ctx);
  show("strategy");
}

function updateStratStatus(hasSaved) {
  $("#stratStatus").innerHTML = strat.dirty
    ? `<span class="warn-text">● Kaydedilmemiş değişiklikler var</span>`
    : hasSaved ? `<span class="ok-text">✓ Strateji kayıtlı</span>` : `<span class="muted">Mühendislerin önerisi yüklendi, henüz kaydedilmedi</span>`;
}

$("#saveStratBtn").onclick = async () => {
  if (!strat) return;
  if (new Date(strat.race.scheduled_at).getTime() <= Date.now()) { toast("Yarış başladı, strateji artık değiştirilemez.", true); return; }
  try {
    await busy($("#saveStratBtn"), () => api.saveStrategies(strat.race.id,
      strat.drivers.map((d, k) => ({ driverId: d.id, plan: strat.ctx.plans[k] }))));
    strat.dirty = false;
    updateStratStatus(true);
    toast("Strateji kaydedildi ✓");
  } catch (e) { toast(e.message, true); }
};

$("#stratBack").onclick = () => {
  if (strat && strat.dirty && !confirmLeave()) return;
  showHub();
};
// Kaydedilmemiş değişiklik varsa ilk tıklamada uyar
let leaveArmed = false;
function confirmLeave() {
  if (leaveArmed) { leaveArmed = false; return true; }
  leaveArmed = true;
  toast("Kaydedilmemiş değişiklikler var. Çıkmak için tekrar tıkla.", true);
  setTimeout(() => (leaveArmed = false), 3500);
  return false;
}

/* ---------- BUTONLAR ---------- */
$("#goStrategyBtn").onclick = showStrategy;
$("#goGarageBtn").onclick = showGarage;
$("#garageBack").onclick = showHub;

boot();
