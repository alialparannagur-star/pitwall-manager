/* =========================================================
   PitWall Manager — VERİTABANI KATMANI
   Oyunun Supabase ile konuştuğu her şey bu dosyada.
   ========================================================= */
(function () {
  const db = supabase.createClient(PW_CONFIG.SUPABASE_URL, PW_CONFIG.SUPABASE_KEY);

  // Supabase'in İngilizce hata mesajlarını Türkçeye çevir
  const TR = [
    [/Invalid login credentials/i, "E-posta veya şifre hatalı."],
    [/User already registered/i, "Bu e-posta ile zaten kayıt olunmuş. Giriş yapmayı dene."],
    [/Password should be at least/i, "Şifre en az 6 karakter olmalı."],
    [/Email not confirmed/i, "E-postanı henüz onaylamadın. Gelen kutunu kontrol et."],
    [/Unable to validate email|invalid format/i, "Geçerli bir e-posta adresi yaz."],
    [/profiles_username_key/i, "Bu kullanıcı adı alınmış, başka bir tane dene."],
    [/profiles_username_check/i, "Kullanıcı adı 3-20 karakter olmalı."],
    [/rate limit/i, "Çok fazla deneme yapıldı, biraz bekleyip tekrar dene."],
    [/row-level security/i, "Bu işlem artık yapılamaz (yarış başlamış olabilir)."],
    [/Failed to fetch|NetworkError/i, "Sunucuya ulaşılamadı. İnternet bağlantını kontrol et."],
  ];
  function fail(err) {
    const msg = (err && err.message) || String(err);
    const hit = TR.find(([re]) => re.test(msg));
    throw new Error(hit ? hit[1] : msg);
  }
  const must = (r) => { if (r.error) fail(r.error); return r.data; };

  window.api = {
    // --- Giriş / kayıt ---
    async getUser() {
      const { data } = await db.auth.getSession();
      return data.session ? data.session.user : null;
    },
    async signUp(email, password) {
      const r = await db.auth.signUp({ email, password });
      if (r.error) fail(r.error);
      return { needsConfirm: !r.data.session };
    },
    async signIn(email, password) {
      const r = await db.auth.signInWithPassword({ email, password });
      if (r.error) fail(r.error);
    },
    async signOut() { await db.auth.signOut(); },

    // --- Oyun verileri ---
    async countries() {
      return must(await db.from("countries").select("*").order("name"));
    },
    // Kullanıcının aktif sezondaki takımı (yoksa null)
    async myTeam() {
      const user = await this.getUser();
      if (!user) return null;
      const rows = must(await db.from("teams")
        .select("*, drivers(*), leagues(id, name, tier, country_code, season_id, seasons(id, number, start_date, status), countries(name, flag, timezone))")
        .eq("owner_id", user.id));
      return rows.find((t) => t.leagues && t.leagues.seasons && t.leagues.seasons.status === "active") || null;
    },
    async joinGame(username, country, teamName) {
      return must(await db.rpc("join_game", { p_username: username, p_country: country, p_team_name: teamName || null }));
    },
    async leagueTeams(leagueId) {
      return must(await db.from("teams").select("*, drivers(*), profiles(username)").eq("league_id", leagueId));
    },
    async leagueRaces(leagueId) {
      return must(await db.from("races").select("id, round, track_id, scheduled_at, status").eq("league_id", leagueId).order("round"));
    },
    async myStrategies(raceId) {
      return must(await db.from("strategies").select("driver_id, plan, updated_at").eq("race_id", raceId));
    },
    async saveStrategies(raceId, items) {
      const now = new Date().toISOString();
      must(await db.from("strategies").upsert(items.map((x) => ({ race_id: raceId, driver_id: x.driverId, plan: x.plan, updated_at: now }))));
    },
    async buyUpgrade(part) {
      return must(await db.rpc("buy_upgrade", { p_part: part }));
    },
  };
})();
